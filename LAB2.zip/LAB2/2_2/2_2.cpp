#include<bits/stdc++.h>
using namespace std;

void insertionSort(vector<int> A,int m,int n){
    for(int i=m;i<n;i++){
        int key = A[i];
        int j=i-1;
        while(j>=0 && A[j]>key){
            A[j+1]=A[j];
            j--;
        }
        A[j+1]=key;
    }
}

int main(){

    freopen("input.txt", 'r', stdin);
    freopen("output.txt", 'w', stdout);

    int n,m;
    cin>>n>>m;

    vector<int> A(n);
    for(int i=0;i<n;i++){cin>>A[i];}

    clock_t start,end;
    start=clock();
    insertionSort(A,m,n);
    end=clock();

    cout<<"The sorted array : "<<endl;
    for(int i=0;i<n;i++){
        cout<<A[i]<<" ";
    }
    cout<<endl;
    double time_taken = double(end-start)/double(CLOCKS_PER_SEC);
    cout<<"The time taken: "<<time_taken<<" sec"<<endl;
}