#include <bits/stdc++.h>
using namespace std;

void sort(vector<long long>& a, int m) {
    int n = a.size();
    int i = 0, j = m, k = 0;
    long long mod = 10000000000;
    while (k < n) {
        if (j == n || (a[i] % mod) < (a[j] % mod)) {
            a[k] += mod * (a[i] % mod);
            i++; k++;
        }
        else if (i == m || (a[i] % mod) >= (a[j] % mod)) {
            a[k] += mod * (a[j] % mod);
            j++; k++;
        }
    }
    for (int i = 0; i < n; i++)
        a[i] = (a[i] / mod);
}

int main() {

    freopen("input.txt", "r", stdin);
    freopen("output.txt", "w", stdout);

    int n;
    cin >> n;

    vector<int> a(n);

    for (int i = 0; i < n; i++)
        cin >> a[i];

    sort(a, n);

    for (int& x : a)
        cout << x << " ";


    return 0;
}