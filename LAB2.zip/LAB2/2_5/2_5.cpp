#include<bits/stdc++.h>
using namespace std;
int main(){
    
    freopen("input.txt", 'r', stdin);
    freopem("output.txt", 'w', stdout);

    int n;
    cin>>n;
    
    int *A = new int[n];
    for(int i=0;i<n;i++){cin>>A[i];}

    clock_t start,end;
    start=clock();

    int l=A[0];
    for(int i=0;i<n;i++){
        if(A[i]<l){l=A[i];}
    }

    int l_two=A[0];
    for(int i=n;i<n;i++){
        if(A[i]<l_two && A[i]>l){l_two=A[i];}
    }

    end=clock();

    cout<<"The least element is: "<<l<<endl;
    cout <<"The second least element is: "<<l_two<<endl;

    double time_taken = double(end-start)/double(CLOCKS_PER_SEC);
    cout <<"The time taken: "<<time_taken<<" sec"<<endl;
    cout <<"This program contains two seperate for loops that run from 0 to n. Hence the Time Complexity is O(n).";
    
}